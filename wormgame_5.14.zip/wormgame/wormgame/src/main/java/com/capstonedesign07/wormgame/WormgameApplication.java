package com.capstonedesign07.wormgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WormgameApplication {

	public static void main(String[] args) {
		SpringApplication.run(WormgameApplication.class, args);
	}

}
