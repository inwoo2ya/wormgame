package com.capstonedesign07.wormgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WormgameApplicationTests {

	@Test
	void contextLoads() {
	}

}
